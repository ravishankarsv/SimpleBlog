<html>
<body>
<?php
$nameErr = $emailErr = $genderErr = $websiteErr = "";
$name = $email = $gender = $comment = $website = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (empty($_POST["name"])){
        $nameerr ="Name is required";
        }
                else {
                $name = test_input($_POST["name"]);
                        if (!preg_match("/^[a-zA-Z ]*$/",$name)) {
                        $nameErr = "Only Letters and white space allowed";
                        }
                }
                }
?>

<form method="post" action="input.php">
Your Name: <input type="text" name="name" size="20">
<br><br>
Your E-Mail ID: <input type="text" name="emailid" size="20">
<br><br>
Your Comments: <input type="text" name="comments" size="20">
<br><br>
<input type="submit" name="submit" value="Submit">
</body>
</html>
