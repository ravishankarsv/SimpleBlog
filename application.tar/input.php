<?php

//the example of inserting data with variable from HTML form
//input.php


$name = $_POST['name'];
$emailid = $_POST['emailid'];
$comments = $_POST['comments'];

mysql_connect("localhost","root","root");//database connection
mysql_select_db("myblog");
//inserting data order
$order = "INSERT INTO blog_comments ".
            "(name,emailid,comments) ".
            "VALUES('$name','$emailid','$comments')";

//declare in the order variable
$result = mysql_query($order);  //order executes
if($result){
    echo("<br>Thank You for contacting Us..!!");
} else{
    echo("<br>Please try again later..!!");
}
?>
